Bebas Kai is a trademark of Dharma Type.
